<?php

//Define your host here.
$HostName = "localhost";

//Define your database username here.
$HostUser = "id15022026_root";

//Define your database password here.
$HostPass = "v.UQ%+YAXgHiu4y";

//Define your database name here.
$DatabaseName = "id15022026_belbiesmarket";

$conn = new mysqli($HostName, $HostUser, $HostPass, $DatabaseName);

if($conn)
{
     //echo "connected";
}
else
{
      //  echo "Not connected";
 
}

?>